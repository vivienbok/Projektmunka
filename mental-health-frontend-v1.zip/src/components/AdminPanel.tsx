import React from 'react';
const AdminPanel: React.FC = () => <div className="p-6">AdminPanel component</div>;
export default AdminPanel;
