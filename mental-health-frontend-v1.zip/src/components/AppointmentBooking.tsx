import React from 'react';
const AppointmentBooking: React.FC = () => <div className='p-6'>Appointment Booking Component</div>;
export default AppointmentBooking;