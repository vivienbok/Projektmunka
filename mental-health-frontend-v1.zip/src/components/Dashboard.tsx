import React from 'react';
const Dashboard: React.FC<{userRole: 'patient' | 'counselor' | 'admin'}> = ({ userRole }) => <div className='p-6'>Dashboard view for {userRole}</div>;
export default Dashboard;