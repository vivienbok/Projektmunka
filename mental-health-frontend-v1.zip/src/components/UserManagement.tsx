import React from 'react';
const UserManagement: React.FC = () => <div className="p-6">UserManagement component</div>;
export default UserManagement;
