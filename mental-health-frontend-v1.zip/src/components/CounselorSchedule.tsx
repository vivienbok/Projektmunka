import React from 'react';
const CounselorSchedule: React.FC<{userRole: 'counselor' | 'admin'}> = ({ userRole }) => <div className='p-6'>Counselor Schedule for {userRole}</div>;
export default CounselorSchedule;