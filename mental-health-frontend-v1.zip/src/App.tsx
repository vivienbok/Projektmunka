import React, { useState } from 'react';
import { Calendar, Users, Settings, BookOpen, Clock, User } from 'lucide-react';
import Dashboard from './components/Dashboard';
import AppointmentBooking from './components/AppointmentBooking';
import CounselorSchedule from './components/CounselorSchedule';
import AdminPanel from './components/AdminPanel';
import UserManagement from './components/UserManagement';

type UserRole = 'patient' | 'counselor' | 'admin';
type ActiveView = 'dashboard' | 'booking' | 'schedule' | 'admin' | 'users';

const App: React.FC = () => {
  const [activeView, setActiveView] = useState<ActiveView>('dashboard');
  const [userRole, setUserRole] = useState<UserRole>('patient');

  const navigationItems = [
    { id: 'dashboard', label: 'Áttekintés', icon: BookOpen, roles: ['patient', 'counselor', 'admin'] },
    { id: 'booking', label: 'Időpont foglalás', icon: Calendar, roles: ['patient'] },
    { id: 'schedule', label: 'Időbeosztás', icon: Clock, roles: ['counselor', 'admin'] },
    { id: 'users', label: 'Felhasználók', icon: Users, roles: ['admin'] },
    { id: 'admin', label: 'Adminisztráció', icon: Settings, roles: ['admin'] },
  ];

  const filteredNavItems = navigationItems.filter(item => item.roles.includes(userRole));

  const renderContent = () => {
    switch (activeView) {
      case 'dashboard':
        return <Dashboard userRole={userRole} />;
      case 'booking':
        return <AppointmentBooking />;
      case 'schedule':
        return <CounselorSchedule userRole={userRole} />;
      case 'users':
        return <UserManagement />;
      case 'admin':
        return <AdminPanel />;
      default:
        return <Dashboard userRole={userRole} />;
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-white" />
                </div>
                <h1 className="text-xl font-bold text-slate-900">
                  Mentálhigiénés Tanácsadás
                </h1>
              </div>
            </div>
          </div>
        </div>
      </header>
      <main className="p-6">{renderContent()}</main>
    </div>
  );
};

export default App;
