import { Router } from 'express';
import { createPool } from '../lib/db.js';

export const usersRouter = Router();

usersRouter.get('/', async (req, res) => {
  try {
    const pool = createPool();
    const [rows] = await pool.query('SELECT id, name, email, role, created_at FROM users ORDER BY id ASC');
    res.json(rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});


