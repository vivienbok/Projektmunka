import { Router } from 'express';
import { createPool } from '../lib/db.js';

export const appointmentsRouter = Router();

appointmentsRouter.get('/', async (req, res) => {
  const pool = createPool();
  try {
    const [rows] = await pool.query(
      'SELECT a.id, a.counselor_id, a.date, a.duration, a.type, a.status, a.note, u.name AS counselor_name FROM appointments a JOIN users u ON a.counselor_id = u.id ORDER BY a.date ASC'
    );
    res.json(rows);
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});


