import { Router } from 'express';
import { createPool } from '../lib/db.js';

export const bookingsRouter = Router();

bookingsRouter.post('/', async (req, res) => {
  const { appointment_id, patient_id, notes = null } = req.body || {};
  if (!appointment_id || !patient_id) return res.status(400).json({ error: 'Missing fields' });
  try {
    const pool = createPool();
    const [result] = await pool.query(
      'INSERT INTO bookings (appointment_id, patient_id, notes) VALUES (?,?,?)',
      [appointment_id, patient_id, notes]
    );
    res.status(201).json({ id: result.insertId, appointment_id, patient_id, status: 'pending', notes });
  } catch (e) {
    console.error(e);
    res.status(500).json({ error: 'Server error' });
  }
});


