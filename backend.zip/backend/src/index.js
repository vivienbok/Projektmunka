import 'dotenv/config';
import express from 'express';
import cors from 'cors';
import { createPool } from './lib/db.js';
import { authRouter } from './routes/auth.js';
import { appointmentsRouter } from './routes/appointments.js';
import { bookingsRouter } from './routes/bookings.js';
import { usersRouter } from './routes/users.js';

const app = express();

const PORT = process.env.PORT || 3000;
const FRONTEND_ORIGIN = process.env.FRONTEND_ORIGIN || 'http://localhost:5173';

app.use(cors({ origin: FRONTEND_ORIGIN, credentials: true }));
app.use(express.json());

// DB healthcheck middleware
app.use(async (req, res, next) => {
  try {
    const pool = createPool();
    await pool.getConnection();
    next();
  } catch (err) {
    console.error('DB connection error:', err.message);
    res.status(500).json({ error: 'Database connection failed' });
  }
});

app.get('/api/health', (req, res) => {
  res.json({ ok: true, service: 'web2-backend' });
});

app.use('/api/auth', authRouter);
app.use('/api/appointments', appointmentsRouter);
app.use('/api/bookings', bookingsRouter);
app.use('/api/users', usersRouter);

app.use((req, res) => {
  res.status(404).json({ error: 'Not found' });
});

app.listen(PORT, () => {
  console.log(`Server listening on http://localhost:${PORT}`);
});


