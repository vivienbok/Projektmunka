Backend (Express + MySQL)

Setup

1. Create database and tables
   - Import the SQL dump you have: `appointments.sql` (contains `users`, `appointments`, `bookings`, etc.)

2. Configure environment variables (create `.env` in `backend/`)

   PORT=3001
   DB_HOST=localhost
   DB_PORT=3306
   DB_USER=root
   DB_PASSWORD=your_password
   DB_NAME=mental_health
   FRONTEND_ORIGIN=http://localhost:5173

3. Install and run
   npm install
   npm run dev

Endpoints

- GET /api/health
- POST /api/auth/register {name,email,password,role?}
- POST /api/auth/login {email,password}
- GET /api/appointments
- POST /api/bookings {appointment_id, patient_id, notes?}
- GET /api/users


