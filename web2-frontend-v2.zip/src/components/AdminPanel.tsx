import React from 'react';

const AdminPanel: React.FC = ()=>{
  return (<div><h2 className="text-2xl font-bold mb-4">Adminisztráció</h2><div className="bg-white rounded-xl p-6 border">Ez egy demo admin panel. Itt lehetne statisztika, rendszernapló, stb.</div></div>);
};

export default AdminPanel;
