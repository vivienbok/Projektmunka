import React, { useState } from 'react';

const UserManagement: React.FC = ()=>{
  const [users] = useState([{id:'p1',name:'Kiss Márta',email:'hallgato@email.com',role:'patient'},{id:'c1',name:'Dr. Nagy',email:'nagy.peter@egyetem.hu',role:'counselor'}]);
  return (<div><h2 className="text-2xl font-bold mb-4">Felhasználók</h2><div className="bg-white rounded-xl p-4 border"><table className="w-full"><thead><tr><th className="text-left">Név</th><th className="text-left">E-mail</th><th className="text-left">Szerep</th></tr></thead><tbody>{users.map(u=>(<tr key={u.id}><td className="py-2">{u.name}</td><td>{u.email}</td><td>{u.role}</td></tr>))}</tbody></table></div></div>);
};

export default UserManagement;
