import React, { useState, useEffect } from 'react';
import { Calendar, Clock, Users, CheckCircle, AlertCircle, TrendingUp, User } from 'lucide-react';

interface UserData { id:string; name:string; email:string; role:'patient'|'counselor'|'admin'; }
interface DashboardProps { userRole: 'patient'|'counselor'|'admin'; currentUser: UserData; }

const Dashboard: React.FC<DashboardProps> = ({ userRole, currentUser }) => {
  const [appointments, setAppointments] = useState<any[]>([
    { id: 'a1', text: 'Konzultáció - Dr. Nagy', date: new Date(Date.now()+86400000).toISOString(), status: 'available', note: 'Első konzultáció' },
    { id: 'a2', text: 'Konzultáció - Dr. Kovács', date: new Date(Date.now()+172800000).toISOString(), status: 'booked', note: 'Páciens: Kiss Márta' }
  ]);
  const [bookings, setBookings] = useState<any[]>([
    { id: 'b1', patientName: 'Kiss Márta', date: new Date().toISOString(), status: 'confirmed' }
  ]);
  const [loading, setLoading] = useState(false);

  useEffect(()=>{ setLoading(true); const t=setTimeout(()=>setLoading(false),300); return ()=>clearTimeout(t); },[]);

  const stats = {
    availableAppointments: appointments.filter(a=>a.status==='available').length,
    bookedAppointments: appointments.filter(a=>a.status==='booked').length,
    confirmedBookings: bookings.filter(b=>b.status==='confirmed').length,
    pendingBookings: bookings.filter(b=>b.status==='pending').length,
    totalAppointments: appointments.length,
    totalBookings: bookings.length
  };

  const getUpcoming = ()=> appointments.filter(a=> new Date(a.date)>new Date()).slice(0,5);
  const getRecent = ()=> bookings.slice(0,5);

  const formatDate=(d:string)=> new Date(d).toLocaleString('hu-HU',{year:'numeric',month:'long',day:'numeric',hour:'2-digit',minute:'2-digit'});

  if(loading) return <div className="flex items-center justify-center h-64"><div className="animate-spin rounded-full h-12 w-12 border-b-2 border-blue-600"></div></div>;

  return (
    <div className="space-y-6">
      <div className="bg-gradient-to-r from-blue-600 to-purple-600 rounded-xl p-6 text-white">
        <h2 className="text-2xl font-bold mb-2">Üdvözöljük a Mentálhigiénés Tanácsadó Rendszerben!</h2>
        <p className="text-blue-100">{userRole==='patient'?'Itt foglalhat időpontot.' : userRole==='counselor' ? 'Kezelheti időbeosztását.' : 'Teljes hozzáférése van a rendszerhez.'}</p>
        <p className="text-blue-200 text-sm mt-1">Bejelentkezve: {currentUser.email}</p>
      </div>

      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-6">
        <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200"><p className="text-sm text-slate-600">Elérhető időpontok</p><p className="text-2xl font-bold">{stats.availableAppointments}</p></div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200"><p className="text-sm text-slate-600">Lefoglalt időpontok</p><p className="text-2xl font-bold">{stats.bookedAppointments}</p></div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200"><p className="text-sm text-slate-600">Megerősített foglalások</p><p className="text-2xl font-bold">{stats.confirmedBookings}</p></div>
        <div className="bg-white rounded-xl p-6 shadow-sm border border-slate-200"><p className="text-sm text-slate-600">Függő foglalások</p><p className="text-2xl font-bold">{stats.pendingBookings}</p></div>
      </div>

      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="text-lg font-semibold mb-4">Közelgő elérhető időpontok</h3>
          {getUpcoming().length? getUpcoming().map(a=> (
            <div key={a.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg mb-2">
              <div><p className="font-medium">{a.text}</p><p className="text-sm text-slate-600">{formatDate(a.date)}</p></div>
              <span className="px-3 py-1 rounded-full text-xs font-medium bg-green-50 text-green-600">Elérhető</span>
            </div>
          )): <p className="text-center text-slate-500 py-8">Nincsenek közelgő időpontok</p>}
        </div>
        <div className="bg-white rounded-xl shadow-sm border border-slate-200 p-6">
          <h3 className="text-lg font-semibold mb-4">Legutóbbi foglalások</h3>
          {getRecent().length? getRecent().map(b=>(<div key={b.id} className="flex items-center justify-between p-4 bg-slate-50 rounded-lg mb-2"><div><p className="font-medium">{b.patientName}</p><p className="text-sm text-slate-600">Foglalás: {formatDate(b.date)}</p></div><span className="px-3 py-1 rounded-full text-xs font-medium bg-blue-50 text-blue-600">Megerősített</span></div>)) : <p className="text-center text-slate-500 py-8">Nincsenek foglalások</p>}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
