import React, { useState } from 'react';
import { Calendar, Shield, Stethoscope, User, Eye, EyeOff, Lock, Mail, AlertCircle } from 'lucide-react';

interface LoginPageProps {
  onLogin: (userRole: 'patient' | 'counselor' | 'admin', userData: any) => void;
}

interface UserCredentials {
  email: string;
  password: string;
  role: 'patient' | 'counselor' | 'admin';
  name: string;
  id: string;
}

const demoUsers: UserCredentials[] = [
  { email: 'admin@egyetem.hu', password: 'admin123', role: 'admin', name: 'Admin Felhasználó', id: 'admin_001' },
  { email: 'nagy.peter@egyetem.hu', password: 'counselor123', role: 'counselor', name: 'Dr. Nagy Péter', id: 'counselor_001' },
  { email: 'kovacs.anna@egyetem.hu', password: 'counselor123', role: 'counselor', name: 'Dr. Kovács Anna', id: 'counselor_002' },
  { email: 'hallgato@email.com', password: 'patient123', role: 'patient', name: 'Kiss Márta', id: 'patient_001' }
];

const LoginPage: React.FC<LoginPageProps> = ({ onLogin }) => {
  const [formData, setFormData] = useState({ email: '', password: '' });
  const [showPassword, setShowPassword] = useState(false);
  const [error, setError] = useState('');
  const [loading, setLoading] = useState(false);
  const [selectedDemo, setSelectedDemo] = useState('');

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    setError(''); setLoading(true);
    await new Promise(r=>setTimeout(r,700));
    const user = demoUsers.find(u => u.email===formData.email && u.password===formData.password);
    if (user) onLogin(user.role, { id: user.id, name: user.name, email: user.email, role: user.role });
    else setError('Hibás e-mail vagy jelszó');
    setLoading(false);
  };

  const handleDemoLogin = (email:string) => {
    const u = demoUsers.find(d=>d.email===email);
    if(u){ setFormData({ email: u.email, password: u.password }); setSelectedDemo(email); }
  };

  const getRoleIcon = (role:string)=> { switch(role){ case 'admin': return <Shield className="w-5 h-5"/>; case 'counselor': return <Stethoscope className="w-5 h-5"/>; default: return <User className="w-5 h-5"/> } };
  const getRoleColor = (role:string)=> { switch(role){ case 'admin': return 'border-red-200 bg-red-50 text-red-700 hover:bg-red-100'; case 'counselor': return 'border-blue-200 bg-blue-50 text-blue-700 hover:bg-blue-100'; default: return 'border-green-200 bg-green-50 text-green-700 hover:bg-green-100' } };
  const getRoleLabel = (role:string)=> { switch(role){ case 'admin': return 'Adminisztrátor'; case 'counselor': return 'Tanácsadó'; default: return 'Páciens' } };

  return (
    <div className="min-h-screen bg-gradient-to-br from-blue-50 via-white to-purple-50 flex items-center justify-center p-4">
      <div className="max-w-md w-full">
        <div className="text-center mb-8">
          <div className="flex justify-center mb-4">
            <div className="w-16 h-16 bg-gradient-to-r from-blue-600 to-purple-600 rounded-2xl flex items-center justify-center shadow-lg">
              <Calendar className="w-8 h-8 text-white" />
            </div>
          </div>
          <h1 className="text-3xl font-bold text-slate-900 mb-2">Mentálhigiénés Tanácsadás</h1>
          <p className="text-slate-600">Jelentkezzen be a rendszerbe</p>
        </div>

        <div className="bg-white rounded-2xl shadow-xl border border-slate-200 p-8">
          <form onSubmit={handleSubmit} className="space-y-6">
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">E-mail cím</label>
              <div className="relative">
                <Mail className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input type="email" required value={formData.email} onChange={(e)=>setFormData({...formData,email:e.target.value})} className="w-full pl-10 pr-4 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="pelda@egyetem.hu" />
              </div>
            </div>
            <div>
              <label className="block text-sm font-medium text-slate-700 mb-2">Jelszó</label>
              <div className="relative">
                <Lock className="absolute left-3 top-1/2 transform -translate-y-1/2 w-5 h-5 text-slate-400" />
                <input type={showPassword ? 'text' : 'password'} required value={formData.password} onChange={(e)=>setFormData({...formData,password:e.target.value})} className="w-full pl-10 pr-12 py-3 border border-slate-300 rounded-lg focus:outline-none focus:ring-2 focus:ring-blue-500" placeholder="••••••••" />
                <button type="button" onClick={()=>setShowPassword(!showPassword)} className="absolute right-3 top-1/2 transform -translate-y-1/2 text-slate-400">{showPassword ? <EyeOff className="w-5 h-5"/> : <Eye className="w-5 h-5"/>}</button>
              </div>
            </div>

            {error && <div className="flex items-center space-x-2 text-red-600 bg-red-50 p-3 rounded-lg border border-red-200"><AlertCircle className="w-5 h-5"/><span className="text-sm">{error}</span></div>}

            <button type="submit" disabled={loading} className="w-full bg-gradient-to-r from-blue-600 to-purple-600 text-white py-3 rounded-lg font-medium hover:from-blue-700 hover:to-purple-700 disabled:opacity-50">
              {loading ? <div className="flex items-center justify-center space-x-2"><div className="w-5 h-5 border-2 border-white border-t-transparent rounded-full animate-spin"></div><span>Bejelentkezés...</span></div> : 'Bejelentkezés'}
            </button>
          </form>

          <div className="mt-8 pt-6 border-t border-slate-200">
            <h3 className="text-sm font-medium text-slate-700 mb-4 text-center">Demo fiókok teszteléshez:</h3>
            <div className="space-y-2">
              {demoUsers.map(user => (
                <button key={user.email} onClick={()=>handleDemoLogin(user.email)} className={`w-full p-3 rounded-lg border-2 transition-all text-left ${selectedDemo===user.email ? 'border-blue-500 bg-blue-50' : getRoleColor(user.role)}`}>
                  <div className="flex items-center justify-between">
                    <div className="flex items-center space-x-3">{getRoleIcon(user.role)}<div><p className="font-medium text-sm">{user.name}</p><p className="text-xs opacity-75">{user.email}</p></div></div>
                    <div className="text-right"><span className="text-xs font-medium">{getRoleLabel(user.role)}</span><p className="text-xs opacity-75">{user.password}</p></div>
                  </div>
                </button>
              ))}
            </div>
            <p className="text-xs text-slate-500 text-center mt-3">Kattintson egy demo fiókra az automatikus kitöltéshez</p>
          </div>
        </div>

        <div className="text-center mt-6"><p className="text-sm text-slate-500">© 2024 Egyetemi Mentálhigiénés Szolgálat</p></div>
      </div>
    </div>
  );
};

export default LoginPage;
