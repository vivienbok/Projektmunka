import React, { useState } from 'react';
import { Calendar, Clock, Plus, Edit, Trash2 } from 'lucide-react';

interface UserData { id:string; name:string; email:string; role:string; }
interface Props { userRole:string; currentUser:UserData; }

const CounselorSchedule: React.FC<Props> = ({ userRole, currentUser }) => {
  const [appointments, setAppointments] = useState<any[]>([
    { id:'a1', date:new Date(Date.now()+86400000).toISOString(), duration:50, type:'online', status:'available' },
    { id:'a2', date:new Date(Date.now()+172800000).toISOString(), duration:50, type:'person', status:'booked' }
  ]);
  const [showForm, setShowForm] = useState(false);
  const [form, setForm] = useState({ date:'', time:'09:00', duration:50, type:'online', notes:'' });

  const add = (e:React.FormEvent)=>{ e.preventDefault(); const dt=new Date(form.date+'T'+form.time); setAppointments(prev=>[{ id:'a'+(prev.length+1), date:dt.toISOString(), duration:form.duration, type:form.type, status:'available', note:form.notes },...prev]); setShowForm(false); setForm({date:'',time:'09:00',duration:50,type:'online',notes:''}); };

  const remove = (id:string)=> setAppointments(prev=> prev.filter(p=>p.id!==id));

  return (
    <div className="space-y-6">
      <div className="bg-white rounded-xl p-6 shadow-sm flex items-center justify-between">
        <div><h2 className="text-2xl font-bold">Időbeosztás</h2><p className="text-slate-600">Itt kezelheti az időpontjait.</p></div>
        <button onClick={()=>setShowForm(s=>!s)} className="inline-flex items-center gap-2 bg-blue-600 text-white px-4 py-2 rounded-lg"><Plus className="w-4 h-4"/>Új időpont</button>
      </div>
      {showForm && <div className="bg-white p-6 rounded-xl"><form onSubmit={add} className="grid grid-cols-1 md:grid-cols-2 gap-4"><div><label className="block text-sm">Dátum</label><input type="date" required value={form.date} onChange={e=>setForm({...form,date:e.target.value})} className="w-full px-3 py-2 border rounded-lg"/></div><div><label className="block text-sm">Idő</label><input type="time" required value={form.time} onChange={e=>setForm({...form,time:e.target.value})} className="w-full px-3 py-2 border rounded-lg"/></div><div><label className="block text-sm">Időtartam</label><input type="number" value={form.duration} onChange={e=>setForm({...form,duration:Number(e.target.value)})} className="w-full px-3 py-2 border rounded-lg"/></div><div><label className="block text-sm">Típus</label><select value={form.type} onChange={e=>setForm({...form,type:e.target.value})} className="w-full px-3 py-2 border rounded-lg"><option value="online">Online</option><option value="person">Személyes</option></select></div><div className="md:col-span-2"><label className="block text-sm">Megjegyzés</label><input value={form.notes} onChange={e=>setForm({...form,notes:e.target.value})} className="w-full px-3 py-2 border rounded-lg"/></div><div className="md:col-span-2 flex justify-end gap-2"><button type="button" onClick={()=>setShowForm(false)} className="px-4 py-2 border rounded-lg">Mégse</button><button type="submit" className="px-4 py-2 bg-blue-600 text-white rounded-lg">Hozzáadás</button></div></form></div>}
      <div className="grid grid-cols-1 gap-4">
        {appointments.map(a=>(<div key={a.id} className="bg-white p-4 rounded-xl shadow-sm flex justify-between items-center"><div><p className="font-medium">{new Date(a.date).toLocaleString('hu-HU')}</p><p className="text-sm text-slate-600">{a.type}</p></div><div className="flex gap-2"><button onClick={()=>remove(a.id)} className="px-3 py-1 border rounded-lg inline-flex items-center gap-2"><Trash2 className="w-4 h-4"/>Töröl</button></div></div>))}
      </div>
    </div>
  );
};

export default CounselorSchedule;
