import React, { useState } from 'react';
import { Calendar, Users, Settings, BookOpen, Clock, User, LogOut } from 'lucide-react';
import LoginPage from './components/LoginPage';
import Dashboard from './components/Dashboard';
import AppointmentBooking from './components/AppointmentBooking';
import CounselorSchedule from './components/CounselorSchedule';
import AdminPanel from './components/AdminPanel';
import UserManagement from './components/UserManagement';

type UserRole = 'patient' | 'counselor' | 'admin';
type ActiveView = 'dashboard' | 'booking' | 'schedule' | 'admin' | 'users';

interface UserData {
  id: string;
  name: string;
  email: string;
  role: UserRole;
}

const App: React.FC = () => {
  const [isLoggedIn, setIsLoggedIn] = useState(false);
  const [currentUser, setCurrentUser] = useState<UserData | null>(null);
  const [activeView, setActiveView] = useState<ActiveView>('dashboard');

  const handleLogin = (userRole: UserRole, userData: UserData) => {
    setCurrentUser(userData);
    setIsLoggedIn(true);
    setActiveView('dashboard');
  };

  const handleLogout = () => {
    setCurrentUser(null);
    setIsLoggedIn(false);
    setActiveView('dashboard');
  };

  if (!isLoggedIn || !currentUser) {
    return <LoginPage onLogin={handleLogin} />;
  }

  const navigationItems = [
    { id: 'dashboard', label: 'Áttekintés', icon: BookOpen, roles: ['patient', 'counselor', 'admin'] },
    { id: 'booking', label: 'Időpont foglalás', icon: Calendar, roles: ['patient'] },
    { id: 'schedule', label: 'Időbeosztás', icon: Clock, roles: ['counselor', 'admin'] },
    { id: 'users', label: 'Felhasználók', icon: Users, roles: ['admin'] },
    { id: 'admin', label: 'Adminisztráció', icon: Settings, roles: ['admin'] },
  ];

  const filteredNavItems = navigationItems.filter(item =>
    item.roles.includes(currentUser.role)
  );

  const renderContent = () => {
    switch (activeView) {
      case 'dashboard':
        return <Dashboard userRole={currentUser.role} currentUser={currentUser} />;
      case 'booking':
        return <AppointmentBooking currentUser={currentUser} />;
      case 'schedule':
        return <CounselorSchedule userRole={currentUser.role} currentUser={currentUser} />;
      case 'users':
        return <UserManagement />;
      case 'admin':
        return <AdminPanel />;
      default:
        return <Dashboard userRole={currentUser.role} currentUser={currentUser} />;
    }
  };

  const getRoleColor = (role: UserRole) => {
    switch (role) {
      case 'admin': return 'bg-red-500';
      case 'counselor': return 'bg-blue-500';
      case 'patient': return 'bg-green-500';
    }
  };

  const getRoleLabel = (role: UserRole) => {
    switch (role) {
      case 'admin': return 'Adminisztrátor';
      case 'counselor': return 'Tanácsadó';
      case 'patient': return 'Páciens';
    }
  };

  return (
    <div className="min-h-screen bg-gradient-to-br from-slate-50 to-blue-50">
      {/* Header */}
      <header className="bg-white shadow-sm border-b border-slate-200">
        <div className="max-w-7xl mx-auto px-4 sm:px-6 lg:px-8">
          <div className="flex justify-between items-center h-16">
            <div className="flex items-center space-x-4">
              <div className="flex items-center space-x-2">
                <div className="w-8 h-8 bg-gradient-to-r from-blue-600 to-purple-600 rounded-lg flex items-center justify-center">
                  <Calendar className="w-5 h-5 text-white" />
                </div>
                <h1 className="text-xl font-bold text-slate-900">
                  Mentálhigiénés Tanácsadás
                </h1>
              </div>
            </div>

            <div className="flex items-center space-x-4">
              {/* User Info */}
              <div className="flex items-center space-x-3">
                <div className="text-right">
                  <p className="text-sm font-medium text-slate-900">{currentUser.name}</p>
                  <p className="text-xs text-slate-600">{currentUser.email}</p>
                </div>
                <div className="flex items-center space-x-2">
                  <div className={`w-3 h-3 rounded-full ${getRoleColor(currentUser.role)}`}></div>
                  <span className="text-sm font-medium text-slate-700">
                    {getRoleLabel(currentUser.role)}
                  </span>
                </div>
              </div>

              {/* Logout Button */}
              <button
                onClick={handleLogout}
                className="flex items-center space-x-2 px-3 py-2 text-slate-600 hover:text-slate-900 hover:bg-slate-100 rounded-lg transition-colors"
                title="Kijelentkezés"
              >
                <LogOut className="w-4 h-4" />
                <span className="text-sm">Kilépés</span>
              </button>
            </div>
          </div>
        </div>
      </header>

      <div className="flex">
        {/* Sidebar */}
        <nav className="w-64 bg-white shadow-sm min-h-screen border-r border-slate-200">
          <div className="p-4">
            {/* User Profile Card */}
            <div className="bg-gradient-to-r from-blue-50 to-purple-50 rounded-lg p-4 mb-6 border border-blue-100">
              <div className="flex items-center space-x-3">
                <div className={`w-10 h-10 rounded-full ${getRoleColor(currentUser.role)} flex items-center justify-center text-white font-medium`}>
                  {currentUser.name.charAt(0).toUpperCase()}
                </div>
                <div>
                  <p className="font-medium text-slate-900 text-sm">{currentUser.name}</p>
                  <p className="text-xs text-slate-600">{getRoleLabel(currentUser.role)}</p>
                </div>
              </div>
            </div>

            {/* Navigation */}
            <ul className="space-y-2">
              {filteredNavItems.map((item) => {
                const Icon = item.icon;
                return (
                  <li key={item.id}>
                    <button
                      onClick={() => setActiveView(item.id as ActiveView)}
                      className={`w-full flex items-center space-x-3 px-4 py-3 rounded-lg text-left transition-all duration-200 ${
                        activeView === item.id
                          ? 'bg-blue-50 text-blue-700 border border-blue-200'
                          : 'text-slate-600 hover:bg-slate-50 hover:text-slate-900'
                      }`}
                    >
                      <Icon className="w-5 h-5" />
                      <span className="font-medium">{item.label}</span>
                    </button>
                  </li>
                );
              })}
            </ul>
          </div>
        </nav>

        {/* Main Content */}
        <main className="flex-1 p-6">
          {renderContent()}
        </main>
      </div>
    </div>
  );
};

export default App;
