# Web2 Frontend V2 (Demo)

Ez a projekt egy Vite + React + TypeScript + Tailwind demó verzió, mely a felhasználói felület működését szimulálja dummy adatokkal.

## Telepítés és futtatás

1. Node.js telepítése (ajánlott 18+).
2. A projekt mappájában futtasd:
```bash
npm install
npm run dev
```

3. Nyisd meg a böngésződben: http://localhost:5173

Demo bejelentkezési adatok a Login oldalon találhatóak (gombra kattintva kitöltődnek).
